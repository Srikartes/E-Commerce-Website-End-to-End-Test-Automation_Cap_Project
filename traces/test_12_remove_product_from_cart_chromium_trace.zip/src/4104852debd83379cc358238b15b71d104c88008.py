# from pages.base_page import BasePage


# class CartPage(BasePage):

#     def remove_product(self, product_id=1):
#         self.page.locator(f"#product-{product_id} a.cart_quantity_delete").click()
from playwright.sync_api import Page, expect
from pages.base_page import BasePage


class CartPage(BasePage):
    def __init__(self, page: Page):
        super().__init__(page)
        self.cart_table = page.locator("#cart_info_table")
        self.empty_cart_message = page.locator("#empty_cart")

    def verify_product_in_cart(self, product_id: int, expected_name: str, expected_price: str, expected_qty: str):
        row = self.page.locator(f"#product-{product_id}")
        expect(row).to_be_visible(timeout=10000)
        expect(row.locator(".cart_description h4 a")).to_have_text(expected_name)
        expect(row.locator(".cart_price p")).to_have_text(expected_price)
        expect(row.locator(".cart_quantity button")).to_have_text(expected_qty)

    def remove_product(self, product_id: int):
        delete_btn = self.page.locator(f"#product-{product_id} .cart_quantity_delete")
        delete_btn.click()
        expect(self.page.locator(f"#product-{product_id}")).to_be_hidden(timeout=10000)
